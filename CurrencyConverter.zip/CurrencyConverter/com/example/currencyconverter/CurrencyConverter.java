package com.example.currencyconverter;
import javax.swing.*;
import java.awt.event.*;
import java.text.NumberFormat;
//import java.util.Locale;

public class CurrencyConverter extends JFrame {
    private JComboBox<String> comboFrom;
    private JComboBox<String> comboTo;
    private JTextField textAmount;
    private JButton convertButton;
    private JLabel resultLabel;
    private JTextField textResult; // Nuevo campo de texto para el resultado
    private ExchangeService exchangeService;

    public CurrencyConverter() {
        exchangeService = new ExchangeService();
        setTitle("Currency Converter");
        setSize(400, 300); // Ajusta el tamaño para acomodar el nuevo campo de texto
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        comboFrom = new JComboBox<>(new String[]{"USD", "EUR", "GBP", "JPY", "COP", "MXN", "BRL"});
        comboTo = new JComboBox<>(new String[]{"USD", "EUR", "GBP", "JPY", "COP", "MXN", "BRL"});
        textAmount = new JTextField(10);
        convertButton = new JButton("Convert");
        textResult = new JTextField(10); // Inicializar el nuevo JTextField para resultados
        textResult.setEditable(false); // Hacerlo no editable
        resultLabel = new JLabel("Enter amount and select currencies");

        add(comboFrom);
        add(comboTo);
        add(textAmount);
        add(convertButton);
        add(resultLabel);
        add(textResult); // Añadir el nuevo JTextField al JFrame

        convertButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                performConversion();
            }
        });

        setVisible(true);
    }

    private void performConversion() {
        try {
            String from = (String) comboFrom.getSelectedItem();
            String to = (String) comboTo.getSelectedItem();
            double amount = Double.parseDouble(textAmount.getText());
            double rate = exchangeService.fetchExchangeRate(from, to);
            double result = amount * rate;
            NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(); // Formateador de moneda
            currencyFormat.setMaximumFractionDigits(2); // Limitar a dos decimales
            textResult.setText(currencyFormat.format(result)); // Usar formateador para mostrar el resultado
        } catch (ExchangeService.ExchangeRateException e) {
            textResult.setText("Error: " + e.getMessage());
        } catch (NumberFormatException e) {
            textResult.setText("Error: Invalid amount format.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new CurrencyConverter();
            }
        });
    }
}
