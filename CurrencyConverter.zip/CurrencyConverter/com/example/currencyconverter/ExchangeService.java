package com.example.currencyconverter;

import java.net.URI;
import java.net.http.*;
import java.net.http.HttpResponse.BodyHandlers;
import org.json.JSONObject;

public class ExchangeService {

    public double fetchExchangeRate(String from, String to) throws ExchangeRateException {
        HttpClient client = HttpClient.newHttpClient();
        String apiKey = "10a0ebf54caef98520dafddd";
        String url = String.format("https://api.exchangerate-api.com/v4/latest/%s?apikey=%s", from, apiKey);
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(url))
            .build();

        try {
            HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
            JSONObject jsonObject = new JSONObject(response.body());
            if (jsonObject.has("error")) {
                throw new ExchangeRateException("Error fetching exchange rate: " + jsonObject.getString("error"));
            }
            JSONObject rates = jsonObject.getJSONObject("rates");
            if (!rates.has(to)) {
                throw new ExchangeRateException("No exchange rate available for " + to);
            }
            return rates.getDouble(to);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ExchangeRateException("Request interrupted", e);
        } catch (Exception e) {
            throw new ExchangeRateException("Error fetching exchange rate", e);
        }
    }

    public static class ExchangeRateException extends Exception {
        public ExchangeRateException(String message) {
            super(message);
        }

        public ExchangeRateException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
